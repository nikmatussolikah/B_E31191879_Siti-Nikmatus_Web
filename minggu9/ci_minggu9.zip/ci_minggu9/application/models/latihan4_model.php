<?php 
/**
  * 
  */
 class latihan4_model extends Ci_Model
 {
 	//membuat properti dengan nama var $txt
 	public $txt = 'latihan4';
 	}
 ?>
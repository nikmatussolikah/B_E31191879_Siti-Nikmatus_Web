<!DOCTYPE html>
<html>
<head>
	<title>Hello view</title>
</head>
<body>
	<h2>"Hello World! python"</h2>
</body>
</html>
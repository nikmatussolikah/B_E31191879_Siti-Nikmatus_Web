<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Controller, Model dan View</title>
</head>
<body>
    <h2><?php echo $teks; ?></h2>
    <h3>Menggunakan Controllers, Model dan View</h3>
</body>
</html>
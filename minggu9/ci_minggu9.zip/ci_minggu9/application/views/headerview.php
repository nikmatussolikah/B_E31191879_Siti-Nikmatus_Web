<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<title>Demo View</title>
</head>
<body>
	<h2>Multiple View</h2>
</body>
</html>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<title>Siti Nikmatus Solikah-E31191879</title>
</head>
<body>
	<h2>Hello World dari CI Model</h2>
	<h3> Menggunakan Controllers,model dan View</h3>
</body>
</html>
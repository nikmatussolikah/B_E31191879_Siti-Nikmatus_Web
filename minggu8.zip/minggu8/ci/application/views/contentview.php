<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<title>Demo View</title>
</head>
<body>
	<p> COntoh Penerapan multiple view yang dipanggil dari satu controller</p>
</body>
</html>
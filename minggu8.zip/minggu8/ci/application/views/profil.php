<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<title>Siti Nikmatus Solikah-E31191879</title>
</head>
<body>
	<h2>Halaman Profil</h2>
	<p> Selamat datang ini adalah halaman profil </p>
</body>
</html>
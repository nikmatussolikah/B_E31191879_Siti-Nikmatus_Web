<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<title>Siti Nikmatus Solikah-E31191879</title>
</head>
<body>
	<h2>Halaman Contact</h2>
	<p> Selamat datang ini adalah halaman contact </p>
</body>
</html>
<?php 
/**
  * 
  */
 class Demo_controller extends CI_COntroller
 {
 	
 	public function index()
 	{
 		echo "<h2>Demo Controller<h2>";
 		echo "<br>Function yang di panggil adalah index";
 	}
 	public function aksi()
 	{
 		echo "<h2>Demo Controller<h2>";
 		echo "<br>Function yang di panggil adalah aksi";
 	}
 } ?>